Scenario description : 
Get all unread e-mails and redirect them based on their subject.
The sample above sends e-mails with subject "Andra" to ciorici.andra@gmail.com. e-mails with subject "Ionut" to ionut@deskover.com and e-mails with subject "Lavinia" to "Lavinia@deskover.com"
Trigger this workflow every time you receive an e-mail

There's a save attachement activity (commented) in case you need to do this also.
